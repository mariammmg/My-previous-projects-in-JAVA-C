﻿namespace Aireline_Reservation_System
{
    partial class Booking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.back = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.cfn = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.flightid = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.backbtn = new System.Windows.Forms.Button();
            this.searchbtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.citydeparture = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.seat = new System.Windows.Forms.TextBox();
            this.sourcedate = new System.Windows.Forms.TextBox();
            this.citydepart = new System.Windows.Forms.TextBox();
            this.dest = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.type = new System.Windows.Forms.TextBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.type);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.back);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.cfn);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.name);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.flightid);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.dataGridView2);
            this.panel2.Controls.Add(this.backbtn);
            this.panel2.Controls.Add(this.searchbtn);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.citydeparture);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.seat);
            this.panel2.Controls.Add(this.sourcedate);
            this.panel2.Controls.Add(this.citydepart);
            this.panel2.Controls.Add(this.dest);
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(126, 36);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(857, 612);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.Color.Crimson;
            this.back.ForeColor = System.Drawing.Color.Snow;
            this.back.Location = new System.Drawing.Point(183, 561);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(383, 37);
            this.back.TabIndex = 18;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(53, 453);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(195, 16);
            this.label9.TabIndex = 17;
            this.label9.Text = "Enter Confirmation Number:";
            // 
            // cfn
            // 
            this.cfn.Location = new System.Drawing.Point(56, 472);
            this.cfn.Name = "cfn";
            this.cfn.Size = new System.Drawing.Size(232, 22);
            this.cfn.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(54, 365);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(129, 16);
            this.label8.TabIndex = 15;
            this.label8.Text = "Enter User Name:";
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(56, 384);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(232, 22);
            this.name.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(54, 409);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 16);
            this.label7.TabIndex = 13;
            this.label7.Text = "Enter Flight ID:";
            // 
            // flightid
            // 
            this.flightid.Location = new System.Drawing.Point(56, 428);
            this.flightid.Name = "flightid";
            this.flightid.Size = new System.Drawing.Size(232, 22);
            this.flightid.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGreen;
            this.button1.ForeColor = System.Drawing.Color.Snow;
            this.button1.Location = new System.Drawing.Point(294, 421);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(58, 37);
            this.button1.TabIndex = 11;
            this.button1.Text = "Book";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.GridColor = System.Drawing.Color.LightGray;
            this.dataGridView2.Location = new System.Drawing.Point(366, 40);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(361, 268);
            this.dataGridView2.TabIndex = 10;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.Color.RoyalBlue;
            this.backbtn.ForeColor = System.Drawing.Color.Snow;
            this.backbtn.Location = new System.Drawing.Point(294, 472);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(64, 37);
            this.backbtn.TabIndex = 9;
            this.backbtn.Text = "Cancel";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.backbtn_Click);
            // 
            // searchbtn
            // 
            this.searchbtn.BackColor = System.Drawing.Color.Crimson;
            this.searchbtn.ForeColor = System.Drawing.Color.Snow;
            this.searchbtn.Location = new System.Drawing.Point(85, 288);
            this.searchbtn.Name = "searchbtn";
            this.searchbtn.Size = new System.Drawing.Size(164, 37);
            this.searchbtn.TabIndex = 8;
            this.searchbtn.Text = "Search";
            this.searchbtn.UseVisualStyleBackColor = false;
            this.searchbtn.Click += new System.EventHandler(this.searchbtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(54, 231);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 16);
            this.label6.TabIndex = 7;
            this.label6.Text = "Available Seats:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "Enter Date Source:";
            // 
            // citydeparture
            // 
            this.citydeparture.AutoSize = true;
            this.citydeparture.Location = new System.Drawing.Point(54, 170);
            this.citydeparture.Name = "citydeparture";
            this.citydeparture.Size = new System.Drawing.Size(148, 16);
            this.citydeparture.TabIndex = 5;
            this.citydeparture.Text = "Enter Departure city:";
            this.citydeparture.Click += new System.EventHandler(this.citydeparture_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(53, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(138, 16);
            this.label10.TabIndex = 4;
            this.label10.Text = "Enter Deestination:";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // seat
            // 
            this.seat.Location = new System.Drawing.Point(56, 250);
            this.seat.Name = "seat";
            this.seat.Size = new System.Drawing.Size(232, 22);
            this.seat.TabIndex = 3;
            // 
            // sourcedate
            // 
            this.sourcedate.Location = new System.Drawing.Point(57, 135);
            this.sourcedate.Name = "sourcedate";
            this.sourcedate.Size = new System.Drawing.Size(232, 22);
            this.sourcedate.TabIndex = 2;
            // 
            // citydepart
            // 
            this.citydepart.Location = new System.Drawing.Point(57, 189);
            this.citydepart.Name = "citydepart";
            this.citydepart.Size = new System.Drawing.Size(232, 22);
            this.citydepart.TabIndex = 1;
            this.citydepart.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // dest
            // 
            this.dest.Location = new System.Drawing.Point(56, 77);
            this.dest.Name = "dest";
            this.dest.Size = new System.Drawing.Size(232, 22);
            this.dest.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Crimson;
            this.button2.ForeColor = System.Drawing.Color.Snow;
            this.button2.Location = new System.Drawing.Point(294, 519);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(69, 36);
            this.button2.TabIndex = 19;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(54, 506);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(137, 16);
            this.label11.TabIndex = 20;
            this.label11.Text = "Enter Ticket Class:";
            // 
            // type
            // 
            this.type.Location = new System.Drawing.Point(56, 526);
            this.type.Name = "type";
            this.type.Size = new System.Drawing.Size(232, 22);
            this.type.TabIndex = 22;
            // 
            // Booking
            // 
            this.BackColor = System.Drawing.Color.Purple;
            this.ClientSize = new System.Drawing.Size(1147, 660);
            this.Controls.Add(this.panel2);
            this.Name = "Booking";
            this.Load += new System.EventHandler(this.Booking_Load_1);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox destination;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox datesource;
        private System.Windows.Forms.TextBox departurecity;
        private System.Windows.Forms.TextBox seats;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox seat;
        private System.Windows.Forms.TextBox sourcedate;
        private System.Windows.Forms.TextBox citydepart;
        private System.Windows.Forms.TextBox dest;
        private System.Windows.Forms.Label citydeparture;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button backbtn;
        private System.Windows.Forms.Button searchbtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox flightid;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox cfn;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox type;
        private System.Windows.Forms.Label label11;
    }
}