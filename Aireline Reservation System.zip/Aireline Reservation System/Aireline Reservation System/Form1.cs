﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aireline_Reservation_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void login_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";

            DataTable dt = new DataTable();
            con.Open();
            string query = "SELECT * FROM [CUSTOMER] WHERE USERNAME = @Username AND PASSWORD = @PASSWORD";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Username", name.Text);
            cmd.Parameters.AddWithValue("@PASSWORD", password.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("User Exists");
            }
            else
            {
                MessageBox.Show("Welcome in Aireline Reservation System :)");
            }

            con.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void signin_Click(object sender, EventArgs e)
        {

            

            if (admin.Checked)
            {
                AdminSignup f = new AdminSignup();
                this.Hide();
                f.Show();
            }
            else
            {
                signup f = new signup();
                this.Hide();
                f.Show();
            }
            
        }

        private void cnt_Click(object sender, EventArgs e)
        {
            if(admin.Checked)
            {
                HomePage h = new HomePage();
                this.Hide();
                h.Show();
            }
            else
            {
                Booking b = new Booking();
                this.Hide();
                b.Show();

            }
        }
    }
}
