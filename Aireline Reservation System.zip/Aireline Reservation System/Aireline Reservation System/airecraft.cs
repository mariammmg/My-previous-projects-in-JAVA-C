﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Aireline_Reservation_System
{
    public partial class airecraft : Form
    {
        public airecraft()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";

            DataTable dt = new DataTable();
            con.Open();
            string query = "SELECT * FROM [AIRCRAFT] WHERE AIRCRAFTID = @AIRCRAFTID";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@AIRCRAFTID", id.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();

            if (dt.Rows.Count > 0)
            {
                // Access the first row in the DataTable
                DataRow row = dt.Rows[0];

                speed.Text = row["CRUISINGSPEED"].ToString();
                height.Text = row["HEIGHT"].ToString();
                lenght.Text = row["LENGTH"].ToString();
                manufacture.Text = row["MANUFACTURERNAME"].ToString();
                seats.Text = row["NO_SEATS"].ToString();
                name.Text = row["AIRCRAFTNAME"].ToString();
                type.Text = row["TYPE"].ToString(); 


                // Use the employeeUsername or perform any other operations with it

            }
            else
            {
                // Handle the case when no rows are found
                MessageBox.Show("No Aircraft found with the specified ID");
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";
            con.Open();
            string query = "DELETE FROM [AIRCRAFT] WHERE AIRCRAFTID = @AIRCRAFTID";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@AIRCRAFTID", id.Text);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";
            con.Open();
            string AirCraftQuery = "INSERT INTO AIRCRAFT (AIRCRAFTID,NO_SEATS,TYPE,MANUFACTURERNAME,LENGTH,HEIGHT,CRUISINGSPEED,AIRCRAFTNAME) " +
                           "VALUES (@AIRCRAFTID,@NO_SEATS,@TYPE,@MANUFACTURERNAME,@LENGTH,@HEIGHT,@CRUISINGSPEED,@AIRCRAFTNAME)";
            using (SqlCommand AircraftCmd = new SqlCommand(AirCraftQuery, con))
            {

               
                AircraftCmd.Parameters.AddWithValue("@AIRCRAFTID", id.Text);
                AircraftCmd.Parameters.AddWithValue("@NO_SEATS", int.Parse(seats.Text));
                AircraftCmd.Parameters.AddWithValue("@TYPE", type.Text);
                AircraftCmd.Parameters.AddWithValue("@MANUFACTURERNAME", manufacture.Text);
                AircraftCmd.Parameters.AddWithValue("@LENGTH",int.Parse( lenght.Text));
                AircraftCmd.Parameters.AddWithValue("@HEIGHT", int.Parse(height.Text));
                AircraftCmd.Parameters.AddWithValue("@CRUISINGSPEED", float.Parse(speed.Text));
                AircraftCmd.Parameters.AddWithValue("@AIRCRAFTNAME", name.Text);
            

                AircraftCmd.ExecuteNonQuery();
                con.Close();
            }



            string adminName ="", password="", email="",adminId="";
            DataTable dt = new DataTable();
            con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";

            con.Open();
            string query = "SELECT * FROM [ADMIN] WHERE USERNAME = @USERNAME";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@USERNAME", admin.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            cmd.ExecuteNonQuery();
            con.Close();

            if (dt.Rows.Count > 0)
            {
                // Access the first row in the DataTable
                DataRow row = dt.Rows[0];
                adminId = row["AID"].ToString();
                adminName = row["USERNAME"].ToString();
                password= row["PASSWORD"].ToString();
                email= row["EMAIL"].ToString();


                // Use the employeeUsername or perform any other operations with it

            }
            else
            {
                // Handle the case when no rows are found
                MessageBox.Show("No Admin found with the specified ID");
            }

            con.Open();
            string MangeQuery = "INSERT INTO Manages (USERNAME,EMAIL,AID,AIRCRAFTID)" +
                           "VALUES (@USERNAME,@EMAIL,@AID,@AIRCRAFTID)";
            using (SqlCommand ManageCmd = new SqlCommand(MangeQuery, con))
            {

                ManageCmd.Parameters.AddWithValue("@USERNAME", adminName.ToString());
                ManageCmd.Parameters.AddWithValue("@EMAIL", email.ToString());
                ManageCmd.Parameters.AddWithValue("@AID", adminId.ToString());
                ManageCmd.Parameters.AddWithValue("@AIRCRAFTID", id.Text);


                ManageCmd.ExecuteNonQuery();
                con.Close();
            }


        }

        private void Back_Click(object sender, EventArgs e)
        {
            Application.OpenForms[1].Show();
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection("server=DESKTOP-N0J39EN;database=DOAA;integrated security=true"))
            {
                string query = "UPDATE [AIRCRAFT] SET AIRCRAFTNAME=@AIRCRAFTNAME WHERE AIRCRAFTID=@AIRCRAFTID";
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@AIRCRAFTNAME", name.Text);
                command.Parameters.AddWithValue("@AIRCRAFTID", id.Text);

                command.ExecuteNonQuery();
                connection.Close();
            }
            }
    }
    }

