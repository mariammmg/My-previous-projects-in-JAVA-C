﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Aireline_Reservation_System
{
    public partial class signup : Form
    {
        public signup()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void signupcs_Load(object sender, EventArgs e)
        {

        }

        private void email_TextChanged(object sender, EventArgs e)
        {

        }

        private void create_Click(object sender, EventArgs e)
        {





            using (SqlConnection con = new SqlConnection("server=DESKTOP-N0J39EN;database=DOAA;integrated security=true"))
            {
                con.Open();

                // Insert into USER table
                string userQuery = "INSERT INTO [USER] (USERNAME, PASSWORD, EMAIL, TYPE) " +
                                   "VALUES (@Username, @Password, @Email, @Type)";

                using (SqlCommand userCmd = new SqlCommand(userQuery, con))
                {
                    // Set the parameter values
                    userCmd.Parameters.AddWithValue("@Username", username.Text);
                    userCmd.Parameters.AddWithValue("@Password", password.Text);
                    userCmd.Parameters.AddWithValue("@Email", email.Text);
                    userCmd.Parameters.AddWithValue("@Type", "Customer");

                    // Execute the query
                    userCmd.ExecuteNonQuery();
                }

                // Insert into CUSTOMER table

                string customerQuery = "INSERT INTO CUSTOMER (USERNAME, EMAIL, NATIONALID, AGE, PASSWORD, TYPE, ADDRESS, PHONENUMBER) " +
                                   "VALUES (@Username, @Email, @NationalID, @Age, @Password, @Type, @Address, @PhoneNumber)";

                using (SqlCommand customerCmd = new SqlCommand(customerQuery, con))
                {
                    // Set the parameter values
                    customerCmd.Parameters.AddWithValue("@Username", username.Text);
                    customerCmd.Parameters.AddWithValue("@Email", email.Text);
                    customerCmd.Parameters.AddWithValue("@NationalID", id.Text);
                    customerCmd.Parameters.AddWithValue("@Age", Convert.ToInt32(age.Text));
                    customerCmd.Parameters.AddWithValue("@Password", password.Text);
                    customerCmd.Parameters.AddWithValue("@Type", "Customer");
                    customerCmd.Parameters.AddWithValue("@Address", address.Text);
                    customerCmd.Parameters.AddWithValue("@PhoneNumber", number.Text);

                    // Execute the query
                    customerCmd.ExecuteNonQuery();
                }

            }
        }

        private void type_TextChanged(object sender, EventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {

            Application.OpenForms[0].Show();
            this.Close();

        }

        private void update_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection("server=DESKTOP-N0J39EN;database=DOAA; integrated security = true"))
            {
                connection.Open();

                string query = "UPDATE [CUSTOMER] SET PASSWORD = @PASSWORD, ADDRESS = @ADDRESS, PHONENUMBER = @PHONENUMBER ,EMAIL = @EMAIL WHERE USERNAME = @USERNAME";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PASSWORD", password.Text);
                    command.Parameters.AddWithValue("@ADDRESS", address.Text);
                    command.Parameters.AddWithValue("@PHONENUMBER", number.Text);
                    command.Parameters.AddWithValue("@USERNAME", username.Text);
                    command.Parameters.AddWithValue("@EMAIL", email.Text);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // Update successful
                        MessageBox.Show("Customer record updated successfully");
                    }
                    else
                    {
                        // No rows affected, customer not found or update failed
                        MessageBox.Show("Failed to update customer record");
                    }
                }
            }

        }
    }
}

