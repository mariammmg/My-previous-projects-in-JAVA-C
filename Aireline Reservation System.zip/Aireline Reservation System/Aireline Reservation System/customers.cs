﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aireline_Reservation_System
{
    public partial class customers : Form
    {
        public customers()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void customers_Load(object sender, EventArgs e)
        {

        }

        private void search_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";

            DataTable dt = new DataTable();
            con.Open();
            string query = "SELECT * FROM [CUSTOMER] WHERE USERNAME LIKE @USERNAME";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@USERNAME", "%" + name.Text + "%");

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            dataGridView1.DataSource = dt;

        }

        private void delete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";
            con.Open();
            string query = "DELETE FROM [CUSTOMER] WHERE USERNAME = @USERNAME";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@USERNAME", name.Text);
            cmd.ExecuteNonQuery();
            con.Close();


            con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";
            con.Open();
            query = "DELETE FROM [CUSTOMER] WHERE USERNAME = @USERNAME";
            cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@USERNAME", name.Text);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void back_Click(object sender, EventArgs e)
        {
            Application.OpenForms[1].Show();
            this.Close();
        }
    }
}
