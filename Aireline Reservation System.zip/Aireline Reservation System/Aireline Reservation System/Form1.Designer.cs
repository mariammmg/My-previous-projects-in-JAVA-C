﻿namespace Aireline_Reservation_System
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.username = new System.Windows.Forms.Label();
            this.passwordlabel = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.login = new System.Windows.Forms.Button();
            this.signin = new System.Windows.Forms.Button();
            this.cnt = new System.Windows.Forms.Button();
            this.trouble = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.admin = new System.Windows.Forms.RadioButton();
            this.customer = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.customer);
            this.panel1.Controls.Add(this.admin);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.trouble);
            this.panel1.Controls.Add(this.cnt);
            this.panel1.Controls.Add(this.signin);
            this.panel1.Controls.Add(this.login);
            this.panel1.Controls.Add(this.password);
            this.panel1.Controls.Add(this.name);
            this.panel1.Controls.Add(this.passwordlabel);
            this.panel1.Controls.Add(this.username);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(31, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(818, 485);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.Location = new System.Drawing.Point(315, 111);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(69, 13);
            this.username.TabIndex = 0;
            this.username.Text = "User Name";
            // 
            // passwordlabel
            // 
            this.passwordlabel.AutoSize = true;
            this.passwordlabel.Location = new System.Drawing.Point(322, 157);
            this.passwordlabel.Name = "passwordlabel";
            this.passwordlabel.Size = new System.Drawing.Size(61, 13);
            this.passwordlabel.TabIndex = 1;
            this.passwordlabel.Text = "Password";
            this.passwordlabel.Click += new System.EventHandler(this.label2_Click);
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(398, 104);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(269, 20);
            this.name.TabIndex = 2;
            this.name.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(398, 150);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(269, 20);
            this.password.TabIndex = 3;
            // 
            // login
            // 
            this.login.BackColor = System.Drawing.Color.Crimson;
            this.login.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.login.ForeColor = System.Drawing.Color.Snow;
            this.login.Location = new System.Drawing.Point(398, 231);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(111, 39);
            this.login.TabIndex = 4;
            this.login.Text = "Log in";
            this.login.UseVisualStyleBackColor = false;
            this.login.Click += new System.EventHandler(this.login_Click);
            // 
            // signin
            // 
            this.signin.BackColor = System.Drawing.Color.ForestGreen;
            this.signin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.signin.ForeColor = System.Drawing.Color.Snow;
            this.signin.Location = new System.Drawing.Point(556, 231);
            this.signin.Name = "signin";
            this.signin.Size = new System.Drawing.Size(111, 39);
            this.signin.TabIndex = 5;
            this.signin.Text = "Sign In";
            this.signin.UseVisualStyleBackColor = false;
            this.signin.Click += new System.EventHandler(this.signin_Click);
            // 
            // cnt
            // 
            this.cnt.BackColor = System.Drawing.Color.DodgerBlue;
            this.cnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cnt.ForeColor = System.Drawing.Color.Snow;
            this.cnt.Location = new System.Drawing.Point(437, 289);
            this.cnt.Name = "cnt";
            this.cnt.Size = new System.Drawing.Size(196, 47);
            this.cnt.TabIndex = 6;
            this.cnt.Text = "Continue";
            this.cnt.UseVisualStyleBackColor = false;
            this.cnt.Click += new System.EventHandler(this.cnt_Click);
            // 
            // trouble
            // 
            this.trouble.AutoSize = true;
            this.trouble.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trouble.ForeColor = System.Drawing.Color.MediumBlue;
            this.trouble.Location = new System.Drawing.Point(639, 318);
            this.trouble.Name = "trouble";
            this.trouble.Size = new System.Drawing.Size(138, 18);
            this.trouble.TabIndex = 7;
            this.trouble.Text = "Trouble in Login?";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(31, 89);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(204, 197);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // admin
            // 
            this.admin.AutoSize = true;
            this.admin.Location = new System.Drawing.Point(413, 193);
            this.admin.Name = "admin";
            this.admin.Size = new System.Drawing.Size(59, 17);
            this.admin.TabIndex = 9;
            this.admin.TabStop = true;
            this.admin.Text = "Admin";
            this.admin.UseVisualStyleBackColor = true;
            // 
            // customer
            // 
            this.customer.AutoSize = true;
            this.customer.Location = new System.Drawing.Point(528, 193);
            this.customer.Name = "customer";
            this.customer.Size = new System.Drawing.Size(77, 17);
            this.customer.TabIndex = 10;
            this.customer.TabStop = true;
            this.customer.Text = "Customer";
            this.customer.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Purple;
            this.ClientSize = new System.Drawing.Size(913, 529);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label passwordlabel;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.Button login;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Button signin;
        private System.Windows.Forms.Label trouble;
        private System.Windows.Forms.Button cnt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton customer;
        private System.Windows.Forms.RadioButton admin;
    }
}

