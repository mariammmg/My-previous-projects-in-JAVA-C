﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.Security.Cryptography;

namespace Aireline_Reservation_System
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                using (SqlConnection connection = new SqlConnection("server=DESKTOP-N0J39EN;database=DOAA;integrated security=true"))
                {
                    string query = "UPDATE [FLIGHT] SET NOOFSEATS =@NOOFSEATS,DATESOURCE=@DATESOURCE,DEPARTURETIME=@DEPARTURETIME,ARRIVALTIME=@ARRIVALTIME,DEPARTURECITY=@DEPARTURECITY,DURATION=@DURATION,ARRIVALCITY=@ARRIVALCITY WHERE FLIGHTID=@AID";
                    connection.Open();
                    SqlCommand command = new SqlCommand(query, connection);

                    command.Parameters.AddWithValue("@NOOFSEATS", seats.Text);
                    command.Parameters.AddWithValue("@DATESOURCE", datesource.Text);
                    command.Parameters.AddWithValue("@DEPARTURETIME", departcity.Text);
                    command.Parameters.AddWithValue("@ARRIVALTIME", arivtime.Text);
                    command.Parameters.AddWithValue("@DEPARTURECITY", departcity.Text);
                    command.Parameters.AddWithValue("@DURATION", duration.Text);
                    command.Parameters.AddWithValue("@ARRIVALCITY", destination.Text);
                    command.Parameters.AddWithValue("@AID", id.Text);

                    command.ExecuteNonQuery();
                    connection.Close();

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true" ;
            string query;
            DataTable dt = new DataTable();
            con.Open();
            SqlCommand cmd; 
            if (string.IsNullOrEmpty(id.Text))
            {
                query = "SELECT * FROM [FLIGHT] WHERE  DATESOURCE LIKE @DATESOURCE AND DEPARTURECITY LIKE @DEPARTURECITY AND ARRIVALCITY LIKE @ARRIVALCITY AND NOOFSEATS > @NOOFSEATS";
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@DATESOURCE", "%" + datesource.Text + "%");
                cmd.Parameters.AddWithValue("@DEPARTURECITY", "%" + departcity.Text + "%");
                cmd.Parameters.AddWithValue("@ARRIVALCITY", "%" + destination.Text + "%");

            }
            else
            {
                query = "SELECT * FROM [FLIGHT] WHERE  FLIGHTID  =  @FLIGHTID";
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@FLIGHTID", id.Text);
            }
           
            
            if (!string.IsNullOrEmpty(seats.Text))
            {
                cmd.Parameters.AddWithValue("@NOOFSEATS", int.Parse(seats.Text));
            }
            else
            {
                cmd.Parameters.AddWithValue("@NOOFSEATS", 0);
            }
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();


            if (dt.Rows.Count > 0)
            {
                // Access the first row in the DataTable
                DataRow row = dt.Rows[0];
                id.Text = row["FLIGHTID"].ToString();
                seats.Text = row["NOOFSEATS"].ToString();
                datesource.Text = row["DATESOURCE"].ToString();
                destination.Text = row["ARRIVALCITY"].ToString();
                duration.Text = row["DURATION"].ToString();
                arivtime.Text = row["ARRIVALTIME"].ToString();
                departcity.Text = row["DEPARTURECITY"].ToString();
                departtime.Text = row["DEPARTURETIME"].ToString();
                adminname.Text = row["USERNAME"].ToString();


                // Use the employeeUsername or perform any other operations with it

            }
            else
            {
                // Handle the case when no rows are found
                MessageBox.Show("No Aircraft found with the specified ID");
            }

            dataGridView1.DataSource = dt;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.OpenForms[1].Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";
            con.Open();
            string query = "INSERT INTO FLIGHT (FLIGHTID, USERNAME, NOOFSEATS, DATESOURCE, DEPARTURETIME, ARRIVALTIME, DEPARTURECITY, DURATION, ARRIVALCITY) VALUES (@FLIGHTID, @USERNAME, @NOOFSEATS, @DATESOURCE, @DEPARTURETIME, @ARRIVALTIME, @DEPARTURECITY, @DURATION, @ARRIVALCITY)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@FLIGHTID",id.Text);
            cmd.Parameters.AddWithValue("@USERNAME", adminname.Text);
            cmd.Parameters.AddWithValue("@NOOFSEATS", int.Parse(seats.Text));
            cmd.Parameters.AddWithValue("@DATESOURCE", datesource.Text);
            cmd.Parameters.AddWithValue("@DEPARTURETIME", departtime.Text);
            cmd.Parameters.AddWithValue("@ARRIVALTIME", arivtime.Text);
            cmd.Parameters.AddWithValue("@DEPARTURECITY", destination.Text);
            cmd.Parameters.AddWithValue("@DURATION", float.Parse(duration.Text));
            cmd.Parameters.AddWithValue("@ARRIVALCITY", destination.Text);
       
            cmd.ExecuteNonQuery();
            con.Close();
            //MessageBox("Done");
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void id_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";
            con.Open();
            string query = "DELETE FROM [FLIGHT] WHERE FLIGHTID = @FLIGHTID";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@FLIGHTID", id.Text);
            cmd.ExecuteNonQuery();
            con.Close();

        }
    }
}
