﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Aireline_Reservation_System
{
    public partial class Booking : Form
    {
        public Booking()
        {
            InitializeComponent();
        }

        private void Booking_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void search_Click(object sender, EventArgs e)
        {
     
        }

       

        private void citydeparture_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void Booking_Load_1(object sender, EventArgs e)
        {

        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";

            DataTable dt = new DataTable();
            con.Open();
            string query = "SELECT * FROM [FLIGHT] WHERE DATESOURCE LIKE @DATESOURCE AND ARRIVALCITY LIKE @ARRIVALCITY AND DEPARTURECITY LIKE @DEPARTURECITY AND NOOFSEATS > @NOOFSEATS";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@DATESOURCE", "%" + sourcedate.Text + "%");
            cmd.Parameters.AddWithValue("@DEPARTURECITY", "%" + citydepart.Text + "%");
            cmd.Parameters.AddWithValue("@ARRIVALCITY", "%" + dest.Text + "%");
            if (!string.IsNullOrEmpty(seat.Text))
            {
                cmd.Parameters.AddWithValue("@NOOFSEATS", int.Parse(seat.Text));
            }
            else
            {
                cmd.Parameters.AddWithValue("@NOOFSEATS", 0);
            }
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();
            dataGridView2.DataSource = dt;

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";

            DataTable dt = new DataTable();
            con.Open();
            string query = "SELECT * FROM [TICKET] WHERE FLIGHTID = @FLIGHTID AND USERNAME IS NULL";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@FLIGHTID", flightid.Text );

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            cmd.ExecuteNonQuery();
            con.Close();

            if (dt.Rows.Count > 0)
            {
                // Access the first row in the DataTable
                DataRow row = dt.Rows[0];
               
                    con.Open();
                    query = "UPDATE [TICKET] SET USERNAME = @USERNAME WHERE CONFIRMATIONNUMBER = @CONFIRMATIONNUMBER";
                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@USERNAME", name.Text);
                    cmd.Parameters.AddWithValue("@CONFIRMATIONNUMBER", row["CONFIRMATIONNUMBER"]);
                    cmd.ExecuteNonQuery();
                    con.Close();
                
             

                // Use the employeeUsername or perform any other operations with it
            }
            else
            {
                // Handle the case when no rows are found
                MessageBox.Show("No Flights found with the specified ID OR TICKETS WENT OUT");
            }

        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";
            con.Open();
            string query = "DELETE FROM [TICKET] WHERE CONFIRMATIONNUMBER = @CONFIRMATIONNUMBER ";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@CONFIRMATIONNUMBER", cfn.Text);
     
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void back_Click(object sender, EventArgs e)
        {
            Application.OpenForms[0].Show();
            this.Close();
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection("server=DESKTOP-N0J39EN;database=DOAA;integrated security=true"))
            {
                connection.Open();
                string query = "UPDATE [TICKET] SET TYPE_TICKET=@TYPE_TICKET WHERE CONFIRMATIONNUMBER=@CONFIRMATIONNUMBER";
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@TYPE_TICKET", type.Text);
                command.Parameters.AddWithValue("@CONFIRMATIONNUMBER", cfn.Text);


                command.ExecuteNonQuery();
                connection.Close();



            }
        }
    }
}
