﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Aireline_Reservation_System
{
    public partial class AdminSignup : Form
    {
        public AdminSignup()
        {
            InitializeComponent();
        }

        private void AdminSignup_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection("server=DESKTOP-N0J39EN;database=DOAA;integrated security=true"))
            {
                con.Open();

                // Insert into USER table
                string userQuery = "INSERT INTO [USER] (USERNAME, PASSWORD, EMAIL, TYPE) " +
                                   "VALUES (@Username, @Password, @Email, @Type)";

                using (SqlCommand userCmd = new SqlCommand(userQuery, con))
                {
                    // Set the parameter values
                    userCmd.Parameters.AddWithValue("@Username", name.Text);
                    userCmd.Parameters.AddWithValue("@Password", password.Text);
                    userCmd.Parameters.AddWithValue("@Email", email.Text);
                    userCmd.Parameters.AddWithValue("@Type", "Admin");

                    // Execute the query
                    userCmd.ExecuteNonQuery();
                }

                // Insert into CUSTOMER table


                string AdminQuery = "INSERT INTO ADMIN (USERNAME, EMAIL,AID,PASSWORD, TYPE) " +
                                   "VALUES (@Username, @Email, @AID,@Password, @Type)";

                using (SqlCommand AdminCmd = new SqlCommand(AdminQuery, con))
                {
                    // Set the parameter values
                    AdminCmd.Parameters.AddWithValue("@Username", name.Text);
                    AdminCmd.Parameters.AddWithValue("@Email", email.Text);
                    AdminCmd.Parameters.AddWithValue("@AID", id.Text);
                    AdminCmd.Parameters.AddWithValue("@Password",password.Text);
                    AdminCmd.Parameters.AddWithValue("@Type", "Admin");


                    // Execute the query
                    AdminCmd.ExecuteNonQuery();
                }

            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";
            con.Open();
            string query = "DELETE FROM [ADMIN] WHERE AID = @AID";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@AID", id.Text);
            cmd.ExecuteNonQuery();
            con.Close();


            con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";
            con.Open();
            query = "DELETE FROM [USER] WHERE USERNAME = @USERNAME";
            cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@USERNAME", name.Text);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void search_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "server=DESKTOP-N0J39EN;database=DOAA;integrated security=true";

            DataTable dt = new DataTable();
            con.Open();
            string query = "SELECT * FROM [ADMIN] WHERE AID = @AID";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@AID", id.Text);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            con.Close();

            if (dt.Rows.Count > 0)
            {
                // Access the first row in the DataTable
                DataRow row = dt.Rows[0];
                name.Text = row["USERNAME"].ToString();
                password.Text = row["PASSWORD"].ToString();
                email.Text = row["EMAIL"].ToString();


                // Use the employeeUsername or perform any other operations with it

            }
            else
            {
                // Handle the case when no rows are found
                MessageBox.Show("No Admin found with the specified ID");
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            Application.OpenForms[0].Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection("server=DESKTOP-N0J39EN;database=DOAA;integrated security=true"))
            {
                connection.Open();
                string quer = "UPDATE [ADMIN] SET PASSWORD = @PASSWORD WHERE USERNAME = @USERNAME";  // Updated query will be assigned based on the condition

                SqlCommand cmm = new SqlCommand(quer, connection);

                quer = "UPDATE [Airplane].[dbo].[ADMIN] SET PASSWORD = @PASSWORD WHERE AID = @AID";
                cmm.Parameters.AddWithValue("@USERNAME", name.Text);
                cmm.Parameters.AddWithValue("@PASSWORD", password.Text);
                cmm.Parameters.AddWithValue("@AID", id.Text);
               
                cmm.ExecuteNonQuery();
                
                connection.Close();
                MessageBox.Show("Operation successful");
            }
        }
    }
}
