﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aireline_Reservation_System
{
    public partial class report : Form
    {
        public report()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int totalCustomers;
            int minimum;
            float x;
            float y;
            double business;
            int max_cont = 0;
            int min_cont = 0;
            string max_id = "";
            string min_id = "";

            using (SqlConnection connection = new SqlConnection("server=DESKTOP-N0J39EN;database=DOAA; integrated security = true"))
            {
                connection.Open();

                // Query to get the total number of customers
                string query = "SELECT COUNT(*) FROM CUSTOMER";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    totalCustomers = Convert.ToInt32(command.ExecuteScalar());
                }

                // Query to get the maximum ticket price in Economy class
                string query3 = "SELECT MAX(PRICE) FROM TICKET WHERE TYPE_TICKET = 'Economy'";
                using (SqlCommand command = new SqlCommand(query3, connection))
                {
                    x = Convert.ToSingle(command.ExecuteScalar());
                }

                // Query to get the maximum ticket price in First Class
                string query4 = "SELECT MAX(PRICE) FROM TICKET WHERE TYPE_TICKET = 'firstclass'";
                using (SqlCommand command = new SqlCommand(query4, connection))
                {
                    y = Convert.ToSingle(command.ExecuteScalar());
                }

                // Query to get the maximum ticket price in Business Class
                string query5 = "SELECT MAX(PRICE) FROM TICKET WHERE TYPE_TICKET = 'Businuess'";
                using (SqlCommand command = new SqlCommand(query5, connection))
                {
                    business = Convert.ToDouble(command.ExecuteScalar());
                }

                // Query to get the flight with the maximum number of customers
                string query6 = "SELECT MAX(counter) AS max, FLIGHTID FROM (SELECT COUNT(USERNAME) AS counter, FLIGHTID FROM TICKET GROUP BY FLIGHTID) AS subquery GROUP BY FLIGHTID ORDER BY max DESC";
                using (SqlCommand command = new SqlCommand(query6, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            max_cont = Convert.ToInt32(reader["max"]);
                            max_id = reader["FlightID"].ToString();
                        }
                    }
                }

                // Query to get the flight with the minimum number of customers
                string query1 = "SELECT MIN(counter) AS min, FLIGHTID FROM (SELECT COUNT(USERNAME) AS counter, FLIGHTID FROM TICKET GROUP BY FLIGHTID) AS subquery GROUP BY FLIGHTID ORDER BY min";
                using (SqlCommand command = new SqlCommand(query1, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            min_cont = Convert.ToInt32(reader["min"]);
                            min_id = reader["FlightID"].ToString();
                        }
                    }
                }

                // Update the TextBox with the retrieved information
                box.Text = "\nThe number of Customers which signed up on the system is " + totalCustomers + " Customers" + Environment.NewLine +
                           "\nThe maximum ticket price in Economy is " + x + Environment.NewLine +
                           "\nThe maximum ticket price in First Class is " + y + Environment.NewLine +
                           "\nThe maximum ticket price in Business Class is " + business + Environment.NewLine +
                           "\nThe maximum number of customers who bought tickets is " + max_cont + " which corresponds to flight ID number: " + max_id + Environment.NewLine +
                           "\nThe minimum number of customers who bought tickets is " + min_cont + " which corresponds to flight ID number: " + min_id;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.OpenForms[1].Show();
            this.Close();
        }
    }
        }
