﻿namespace Aireline_Reservation_System
{
    partial class airecraft
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.admin = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.type = new System.Windows.Forms.TextBox();
            this.delete = new System.Windows.Forms.Button();
            this.search = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.lenght = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.speed = new System.Windows.Forms.TextBox();
            this.height = new System.Windows.Forms.TextBox();
            this.manufacture = new System.Windows.Forms.TextBox();
            this.seats = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.admin);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.type);
            this.panel1.Controls.Add(this.delete);
            this.panel1.Controls.Add(this.search);
            this.panel1.Controls.Add(this.Back);
            this.panel1.Controls.Add(this.Add);
            this.panel1.Controls.Add(this.lenght);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.speed);
            this.panel1.Controls.Add(this.height);
            this.panel1.Controls.Add(this.manufacture);
            this.panel1.Controls.Add(this.seats);
            this.panel1.Controls.Add(this.name);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.id);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(83, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(739, 474);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(52, 385);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 16);
            this.label9.TabIndex = 21;
            this.label9.Text = "Adminlabel";
            // 
            // admin
            // 
            this.admin.Location = new System.Drawing.Point(203, 379);
            this.admin.Name = "admin";
            this.admin.Size = new System.Drawing.Size(149, 22);
            this.admin.TabIndex = 20;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(49, 352);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 16);
            this.label8.TabIndex = 19;
            this.label8.Text = "Type:";
            // 
            // type
            // 
            this.type.Location = new System.Drawing.Point(203, 346);
            this.type.Name = "type";
            this.type.Size = new System.Drawing.Size(149, 22);
            this.type.TabIndex = 18;
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.Crimson;
            this.delete.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.delete.Location = new System.Drawing.Point(461, 59);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(70, 37);
            this.delete.TabIndex = 17;
            this.delete.Text = "Delete";
            this.delete.UseVisualStyleBackColor = false;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // search
            // 
            this.search.BackColor = System.Drawing.Color.RoyalBlue;
            this.search.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.search.Location = new System.Drawing.Point(368, 59);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(72, 37);
            this.search.TabIndex = 16;
            this.search.Text = "Search";
            this.search.UseVisualStyleBackColor = false;
            this.search.Click += new System.EventHandler(this.button1_Click);
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.RoyalBlue;
            this.Back.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Back.Location = new System.Drawing.Point(313, 410);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(98, 42);
            this.Back.TabIndex = 15;
            this.Back.Text = "Back";
            this.Back.UseVisualStyleBackColor = false;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.Color.Crimson;
            this.Add.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Add.Location = new System.Drawing.Point(166, 407);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(98, 42);
            this.Add.TabIndex = 14;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // lenght
            // 
            this.lenght.Location = new System.Drawing.Point(203, 308);
            this.lenght.Name = "lenght";
            this.lenght.Size = new System.Drawing.Size(149, 22);
            this.lenght.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(49, 314);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 16);
            this.label7.TabIndex = 12;
            this.label7.Text = "Lenght";
            // 
            // speed
            // 
            this.speed.Location = new System.Drawing.Point(203, 270);
            this.speed.Name = "speed";
            this.speed.Size = new System.Drawing.Size(149, 22);
            this.speed.TabIndex = 11;
            // 
            // height
            // 
            this.height.Location = new System.Drawing.Point(203, 228);
            this.height.Name = "height";
            this.height.Size = new System.Drawing.Size(149, 22);
            this.height.TabIndex = 10;
            // 
            // manufacture
            // 
            this.manufacture.Location = new System.Drawing.Point(203, 182);
            this.manufacture.Name = "manufacture";
            this.manufacture.Size = new System.Drawing.Size(149, 22);
            this.manufacture.TabIndex = 9;
            this.manufacture.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // seats
            // 
            this.seats.Location = new System.Drawing.Point(203, 146);
            this.seats.Name = "seats";
            this.seats.Size = new System.Drawing.Size(149, 22);
            this.seats.TabIndex = 8;
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(203, 110);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(149, 22);
            this.name.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(45, 110);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 16);
            this.label6.TabIndex = 6;
            this.label6.Text = "Airecraft_Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(48, 273);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Speed";
            // 
            // id
            // 
            this.id.Location = new System.Drawing.Point(203, 66);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(147, 22);
            this.id.TabIndex = 4;
            this.id.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Number_Seats:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 188);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(149, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Manufacturer_Name:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 234);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Height";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "AirCraft ID:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGreen;
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(461, 407);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 42);
            this.button1.TabIndex = 22;
            this.button1.Text = "Edit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // airecraft
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Purple;
            this.ClientSize = new System.Drawing.Size(891, 531);
            this.Controls.Add(this.panel1);
            this.Name = "airecraft";
            this.Text = "airecraft";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox id;
        private System.Windows.Forms.TextBox speed;
        private System.Windows.Forms.TextBox height;
        private System.Windows.Forms.TextBox manufacture;
        private System.Windows.Forms.TextBox seats;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.TextBox lenght;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox type;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox admin;
        private System.Windows.Forms.Button button1;
    }
}