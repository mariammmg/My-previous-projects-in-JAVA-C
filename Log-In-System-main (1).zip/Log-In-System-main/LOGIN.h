#ifndef UNTITLED1_LOGIN_H
#define UNTITLED1_LOGIN_H

#include<iostream>
#include<istream>
#include<fstream>
#include <regex>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <ctime>


using namespace std;

void registr();
void login();
void changepass();
void forgotPassword();
void menu();

#endif //UNTITLED1_LOGIN_H
