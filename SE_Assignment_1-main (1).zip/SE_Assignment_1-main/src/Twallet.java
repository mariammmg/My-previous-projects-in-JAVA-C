import java.util.Objects;
import java.util.Scanner;
import java.util.Vector;

public class Twallet extends Transformation {

    private final Vector<User> result;
    private InstaPaySystem s=new InstaPaySystem();
    public Twallet() {
        result = new Vector<>();
    }

    @Override
    public Vector<User> transfer(User source,User target, double amount) {
        (source.getThing()).withdraw(amount);
        (target.getThing()).deposit(amount);
        result.add(source);
        result.add(target);
        return result;
    }
}
