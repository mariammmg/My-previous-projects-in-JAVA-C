public class VodafoneCashUser implements Creations {
    @Override
    public User create_user(String mobilenumber, double balance, String num, String name) {
        User u2 = new User();
        Wallet u1 = new VodafoneCash_wallet(mobilenumber, balance, num);
        u2.setThing(u1);
        u2.setUser_type("vodafoneCashWallet");
        return u2;
    }
}
