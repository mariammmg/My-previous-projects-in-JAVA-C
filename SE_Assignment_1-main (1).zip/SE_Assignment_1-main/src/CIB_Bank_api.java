import java.util.HashMap;
import java.util.Map;

public class CIB_Bank_api implements Bank_api {
    @Override
    public boolean verfication_mobile(String mobileNumber, String accountNumber) {
        Map<String, String> cib_accountMobileMap = new HashMap<>();
        cib_accountMobileMap.put("983456789", "01045566789");
        cib_accountMobileMap.put("987654321", "0104566908");
        return cib_accountMobileMap.containsKey(accountNumber) && cib_accountMobileMap.get(accountNumber).equals(mobileNumber);
    }
}
