public abstract class Bank_account implements UserThing {
    private final String accountNumber;
    private double balance;
    private final String registered_mobile_number;

    public Bank_account(String num, double balance, String accountNumber) {
        this.registered_mobile_number = num;
        this.balance = balance;
        this.accountNumber = accountNumber;
    }

    @Override
    public double getBalance() {
        return balance;
    }

    @Override
    public double withdraw(double money) {
        this.balance = balance - money;
        return balance;
    }

    @Override
    public double deposit(double money) {
        this.balance = balance + money;
        return balance;
    }

    public String getRegistered_mobile_number() {
        return registered_mobile_number;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    @Override
    public void setBalance(double u2) {
        this.balance = u2;
    }
}
