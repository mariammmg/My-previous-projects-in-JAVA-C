public class HSBC_account extends Bank_account {
    private final String bank_name;
    private final Bank_api api;

    public HSBC_account(String num, double balance, String accountnum) {
        super(num, balance, accountnum);
        this.bank_name = "HSBC";
        api = new HSBC_Bank_api();
    }

    public boolean verfiy_account(String mobile, String accountNumber) {
        return api.verfication_mobile(mobile, accountNumber);

    }

}
