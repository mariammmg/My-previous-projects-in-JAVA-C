public class HSBC_user implements Creations {
    @Override
    public User create_user(String mobilenumber, double balance, String num, String name) {
        User u2 = new User();
        Bank_account u1 = new HSBC_account(mobilenumber, balance, num);
        u2.setThing(u1);
        u2.setUser_type("HSBCBankaccount");
        return u2;
    }
}
