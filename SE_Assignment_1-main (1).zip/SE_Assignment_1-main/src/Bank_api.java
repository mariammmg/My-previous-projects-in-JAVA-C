public interface Bank_api {
    boolean verfication_mobile(String mobileNumber, String accountNumber);
}
