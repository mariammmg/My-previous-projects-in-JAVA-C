public interface UserThing {
    double withdraw(double money);

    double deposit(double money);

    void setBalance(double money);

    double getBalance();

}
