import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);

    private static InstaPaySystem instaPay = new InstaPaySystem();
    private static boolean isLoggedIn = false;

//    private static User user = new User();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nWelcome to InstaPay!");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.println("Enter your choice (1-3): ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    instaPay.signup();
                    // implement register
                    break;
                case 2:
                    // implement login
                    isLoggedIn = instaPay.login();
                    boolean flag = true;
                    while (flag){
                        flag = instaPay.transformation();
                    }
//                    showMainMenu();
                    break;
                case 3:
                    System.out.println("Exiting InstaPay. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 3.");
            }
        }
    }

}




