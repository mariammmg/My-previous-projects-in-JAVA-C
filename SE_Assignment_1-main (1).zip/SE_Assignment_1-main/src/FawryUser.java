public class FawryUser implements Creations {
    @Override
    public User create_user(String mobilenumber, double balance, String num, String name) {
        User u2 = new User();
        Wallet u1 = new Fawry_wallet(mobilenumber, balance, num);
        u2.setThing(u1);
        u2.setUser_type("fawryWallet");
        return u2;
    }
}
