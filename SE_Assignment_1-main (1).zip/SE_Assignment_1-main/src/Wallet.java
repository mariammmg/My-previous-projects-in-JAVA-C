public abstract class Wallet implements UserThing {
    private final String WalletID;
    private double balance;
    private final String registered_mobile_number;

    public Wallet(String num, double balance, String ID) {
        this.registered_mobile_number = num;
        this.balance = balance;
        this.WalletID = ID;
    }

    @Override
    public double getBalance() {
        return balance;
    }

    @Override
    public void setBalance(double u2) {
        this.balance = u2;
    }

    @Override
    public double withdraw(double money) {
        this.balance = balance - money;
        return balance;
    }

    @Override
    public double deposit(double money) {
        this.balance = balance + money;
        return balance;
    }

    public String getRegistered_mobile_number() {
        return registered_mobile_number;
    }

    public String getWalletID() {
        return WalletID;
    }
}
