import java.util.Objects;
import java.util.Scanner;
import java.util.Vector;

abstract public class Transformation {
    abstract Vector<User> transfer(User source,User target, double amount);

    Boolean process(User curr, Vector<User> users,User target,Transformation type) {
        boolean check2 = false;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the amount of the money you want to transfer: ");
        double money = in.nextDouble();

        boolean b = money > (curr.getThing()).getBalance();
        if (b) {
            System.out.println("Sorry,your balance not enough");
            process(curr, users,target,type);
        }

            Vector<User> update;
            update = transfer(curr,target, money);
            for (User i : users) {
                if (Objects.equals(i.getUsername(), curr.getUsername())) {
                    i.getThing().setBalance(update.get(0).getThing().getBalance());

                } else if (Objects.equals(i.getUsername(), target.getUsername())) {
                    i.getThing().setBalance(update.get(1).getThing().getBalance());
                }
            }
            return true;
        }

    }

