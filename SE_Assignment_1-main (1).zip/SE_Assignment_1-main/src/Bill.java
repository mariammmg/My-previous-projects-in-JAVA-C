import java.util.*;

abstract class Bill {
    private String billNumber;
    private String dueDate;
    private double cost;

    Transformation payBills = new PayBills();

    InstaPaySystem instaPaySystem = new InstaPaySystem();



    // Constructors, getters, and setters

    // Abstract method that must be implemented by subclasses
    public abstract void processBill(String number, User currentUser);
}

class WaterBill extends Bill {
    Map<String, Integer> WaterBillDetails = new HashMap<String, Integer>();
    Scanner scanner = new Scanner(System.in);

    public WaterBill() {
        WaterBillDetails.put("01020083229", 200);
        WaterBillDetails.put("01020083228", 20);
        WaterBillDetails.put("01011121314", 350);
        WaterBillDetails.put("01011121315", 100);
    }

    public boolean ValidateNumber(String number) {
        String regex = "^010\\d{8}$";
        return number.matches(regex);
    }


    @Override
    public void processBill(String number, User currentUser) {
        if (ValidateNumber(number)) {
            if (WaterBillDetails.containsKey(number)) {
                System.out.println("Your bill is: " + WaterBillDetails.get(number));
                System.out.println("1- Pay");
                System.out.println("2- Cancel");
                int num = scanner.nextInt();
                if (num == 1) {
                    Vector <User> theuser = new Vector<>();

                    theuser = payBills.transfer(currentUser, null,WaterBillDetails.get(number));
                    System.out.println("Your bill is paid");
                    // set the user to the equal user in the vector of users
                    for(User u : instaPaySystem.users){
                        if (Objects.equals(u.getUsername(), currentUser.getUsername()))
                        {
                            // change the user in the vector of users
                            u.getThing().setBalance(theuser.get(0).getThing().getBalance());
                        }
                    }
                    instaPaySystem.UpdateFile(instaPaySystem.users);

                }
                else
                    System.out.println("Your oder is canceled");
            } else {
                System.out.println("This number has not Bills");
            }
        } else {
            System.out.println("Invalid number");
        }
    }
}



class GasBill extends Bill {
    Map<String, Integer> GasBillDetails = new HashMap<String, Integer>();
    Scanner scanner = new Scanner(System.in);

    public GasBill() {
        GasBillDetails.put("01120083229", 200);
        GasBillDetails.put("01120083228", 20);
        GasBillDetails.put("01111121314", 350);
        GasBillDetails.put("01111121315", 100);
    }

    public boolean ValidateNumber(String number) {
        String regex = "^011\\d{8}$";
        return number.matches(regex);
    }
    // Constructors, getters, and setters

    @Override
    public void processBill(String number, User currentUser) {
        if (ValidateNumber(number)) {
            if (GasBillDetails.containsKey(number)) {
                System.out.println("Your bill is: " + GasBillDetails.get(number));
                System.out.println("1- Pay");
                System.out.println("2- Cancel");
                int num = scanner.nextInt();
                if (num == 1) {
                    Vector <User> theuser = new Vector<>();

                    theuser = payBills.transfer(currentUser,null ,GasBillDetails.get(number));
                    System.out.println("Your bill is paid");
                    for(User u : instaPaySystem.users){
                        if (Objects.equals(u.getUsername(), currentUser.getUsername()))
                        {
                            u.getThing().setBalance(theuser.get(0).getThing().getBalance());
                        }
                    }
                    instaPaySystem.UpdateFile(instaPaySystem.users);
                }
                else
                    System.out.println("Your oder is canceled");
            } else {
                System.out.println("This number has not Bills");
            }
        } else {
            System.out.println("Invalid number");
        }
    }
}


class ElectricBill extends Bill {
    Map<String, Integer> ElectricBillDetails = new HashMap<String, Integer>();
    Scanner scanner = new Scanner(System.in);

    public ElectricBill() {
        ElectricBillDetails.put("01220083229", 200);
        ElectricBillDetails.put("01220083228", 20);
        ElectricBillDetails.put("01211121314", 350);
        ElectricBillDetails.put("01211121315", 100);
    }

    public boolean ValidateNumber(String number) {
        String regex = "^012\\d{8}$";
        return number.matches(regex);
    }
    // Constructors, getters, and setters

    @Override
    public void processBill(String number, User currentUser) {
        if (ValidateNumber(number)) {
            if (ElectricBillDetails.containsKey(number)) {
                System.out.println("Your bill is: " + ElectricBillDetails.get(number));
                System.out.println("1- Pay");
                System.out.println("2- Cancel");
                int num = scanner.nextInt();
                if (num == 1) {
                    Vector <User> theuser = new Vector<>();

                    theuser = payBills.transfer(currentUser,null,ElectricBillDetails.get(number));
                    System.out.println("Your bill is paid");
                    for(User u : instaPaySystem.users){
                        if (Objects.equals(u.getUsername(), currentUser.getUsername()))
                        {
                            u.getThing().setBalance(theuser.get(0).getThing().getBalance());

                        }
                    }
                    instaPaySystem.UpdateFile(instaPaySystem.users);
                }
                else
                    System.out.println("Your oder is canceled");
            } else {
                System.out.println("This number has not Bills");
            }
        } else {
            System.out.println("Invalid number");
        }
    }
}

