import java.util.Objects;
import java.util.Scanner;

public class Registeration_Bybank implements Registeration_method {
    @Override
    public boolean register(User u1) {
        boolean verify = true;
        CiB_account acc;
        HSBC_account account;
        if (Objects.equals(u1.getUser_type(), "CIBBankaccount")) {
            acc = (CiB_account) u1.getThing();
            verify = acc.verfiy_account(acc.getRegistered_mobile_number(), acc.getAccountNumber());
            if (verify) {
                System.out.println("otp" + 567390 + "is sent to " + acc.getRegistered_mobile_number() + "mobile number");
                Scanner scanner = new Scanner(System.in);
                int num = scanner.nextInt();
                System.out.println("your  Bank account is verified");
                return true;
            } else {
                System.out.println("you Bank account is not verified");
                return false;
            }
        }
        if (Objects.equals(u1.getUser_type(), "HSBCBankaccount")) {
            account = (HSBC_account) u1.getThing();
            verify = account.verfiy_account(account.getRegistered_mobile_number(), account.getAccountNumber());
            if (verify) {
                System.out.println("otp" + 567990 + "is sent to " + account.getRegistered_mobile_number() + "mobile number");
                Scanner scanner = new Scanner(System.in);
                int num = scanner.nextInt();
                System.out.println("your  Bank account is verified");
                return true;
            } else {
                System.out.println("you Bank account is not verified");
                return false;
            }
        }


        return true;
    }
}
