import java.util.Objects;
import java.util.Vector;

public class Fawry_Api implements Wallet_Provider_Api {
    @Override
    public boolean verfication(String mobileNumber) {
        Vector<String> numbers = new Vector<>();
        numbers.add("01555153638");
        numbers.add("01234678245");
        for (String num : numbers) {
            if (Objects.equals(num, mobileNumber)) {
                return true;
            }
        }
        return false;
    }

}

