import java.util.Vector;

public class PayBills extends Transformation {
    private final Vector<User> result;

    public PayBills() {
        // Initialize the result vector in the constructor
        result = new Vector<>();
    }

    @Override
    public Vector<User> transfer(User source,User target, double amount) {
        source.getThing().withdraw(amount);
        result.add(source);
        return result;
    }
}
