public interface Registeration_method {
    boolean register(User u1);
}
