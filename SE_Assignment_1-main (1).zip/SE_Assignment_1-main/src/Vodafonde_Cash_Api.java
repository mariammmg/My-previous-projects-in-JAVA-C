import java.util.Objects;
import java.util.Vector;

public class Vodafonde_Cash_Api implements Wallet_Provider_Api {
    @Override
    public boolean verfication(String mobileNumber) {
        Vector<String> numbers = new Vector<>();
        numbers.add("01051536389");
        numbers.add("01034678245");
        for (String num : numbers) {
            if (Objects.equals(num, mobileNumber)) {
                return true;
            }
        }
        return false;
    }

}
