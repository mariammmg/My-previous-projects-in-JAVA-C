public class User {
    private String username;
    private UserThing thing;
    private String password;
    private String user_type;

    public void setThing(UserThing thing) {
        this.thing = thing;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }

    public String getUser_type() {
        return user_type;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public UserThing getThing() {
        return thing;
    }
}
