import java.io.*;
import java.util.Objects;
import java.util.Scanner;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InstaPaySystem {
    private Registeration_method method;
    final Vector<User> users = new Vector<>();
    private Creations c;
    private Transformation transfer;

    public User currUser = null;

    public InstaPaySystem() {
        // Initialize the result vector in the constructor
        loadfile();
    }

    public void setC(Creations c) {
        this.c = c;
    }

    public User create(Creations c, String mobilenumber, double balance, String num, String name) {
        return c.create_user(mobilenumber, balance, num, name);

    }

    public void setMethod(Registeration_method method) {
        this.method = method;
    }

    public boolean register_process(Registeration_method method, User u1) {
        return method.register(u1);
    }

    public void signup() {
        boolean found = true;
        User u2 = new User();
        while (found) {

            System.out.println("PLease choose you want to ");
            System.out.println("1- Register by Bank account");
            System.out.println("2- Register by wallet");
            System.out.println("3- Exit");
            Scanner scanner = new Scanner(System.in);
            boolean result = true;
            int num = scanner.nextInt();
            if (num == 1) {

                System.out.println("Please enter your Bank account number");
                String bank_num = scanner.next();
                System.out.println("Please enter your Bank account balance");
                double bank_balance = scanner.nextDouble();
                System.out.println("Please enter your mobile number registered on the bank");
                String mobile_num_bank = scanner.next();
                System.out.println("Please enter your Bank name");
                System.out.println("1- cib");
                System.out.println("2- hsbc");

                String bank_name = scanner.next();
                if (Objects.equals(bank_name, "cib")) {
                    Creations c = new CIB_user();
                    u2 = create(c, mobile_num_bank, bank_balance, bank_num, bank_name);
                }
                if (Objects.equals(bank_name, "hsbc")) {
                    Creations c = new HSBC_user();
                    u2 = create(c, mobile_num_bank, bank_balance, bank_num, bank_name);

                }
                Registeration_method r = new Registeration_Bybank();
                result = register_process(r, u2);
                found = !result;

            }
            if (num == 2) {
                System.out.println("Please enter your wallet balance");
                double wallet_balance = scanner.nextDouble();
                System.out.println("Please enter your mobile number registered on the wallet");
                String mobile_num_wallet = scanner.next();

                System.out.println("those are the wallets providers choose one from them");
                System.out.println("1- fawry");
                System.out.println("2- vodafoneCash");
                System.out.println("Please enter the suitable wallet provider for you");

                String wallet_name = scanner.next();

                if (Objects.equals(wallet_name, "vodafoneCash")) {
                    Creations c = new VodafoneCashUser();
                    u2 = c.create_user(mobile_num_wallet, wallet_balance, mobile_num_wallet, wallet_name);
                }
                if (Objects.equals(wallet_name, "fawry")) {
                    Creations c = new FawryUser();
                    u2 = c.create_user(mobile_num_wallet, wallet_balance, mobile_num_wallet, wallet_name);
                }
                Registeration_method r = new Registeration_Bywallet();
                result = register_process(r, u2);
                found = !result;
            }
            if (num == 3) {
                return;
            }
        }
        boolean flag = true;
        String name = "";
        String password = "";
        while (flag) {
            System.out.println("Enter your username");
            Scanner scanner = new Scanner(System.in);
            name = scanner.next();


            flag = false;
            for (User i : users) {
                if (Objects.equals(i.getUsername(), name)) {
                    flag = true;
                    break;
                }
            }
            System.out.println("Enter your password");
            password = scanner.next();
            boolean check = check_password(password);
            if (!check) {
                flag = true;
                System.out.println("This password is not complex enough");
            }

        }
        u2.setUsername(name);
        u2.setPassword(password);
        users.add(u2);
        Writefile(u2);
        System.out.println("Congratulations your registration is done.");

    }

    public boolean check_password(String password) {
        Pattern pa1 = Pattern.compile("^(?=.*\\d)(?!.*\\s)(?=.*[a-z])(?=.*[A-Z]).{8,32}$");
        Matcher ma1 = pa1.matcher(password);
        return ma1.find();
    }

    public void Writefile(User user1) {
        String filePath = "Database.txt";
        // Specify the path to your file

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {

            String user_type = user1.getUser_type();
            if(user1.getThing() instanceof Wallet)
            {
                Wallet account = (Wallet) user1.getThing();
                writer.write(user1.getUser_type() + "|" + user1.getUsername() + "|" + user1.getPassword() + "|" + account.getRegistered_mobile_number()
                        + "|" + account.getWalletID() + "|" + account.getBalance());
                writer.newLine();
            }
            if(user1.getThing() instanceof Bank_account)
            {
                Bank_account account = (Bank_account) user1.getThing();
                writer.write(user1.getUser_type() + "|" + user1.getUsername() + "|" + user1.getPassword() + "|" + account.getRegistered_mobile_number()
                        + "|" + account.getAccountNumber() + "|" + account.getBalance());
                writer.newLine();
            }


        } catch (IOException e) {
            System.err.println("Error writing to the file: " + e.getMessage());
        }
    }

    public void loadfile() {

        String filePath = "Database.txt"; // Specify the path to your file

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                User user_temp = new User();
                String[] words = line.split("\\|");
                if (Objects.equals(words[0], "CIBBankaccount")) {
                    double doubleValue = Double.parseDouble(words[5]);
                    CiB_account u1 = new CiB_account(words[3].trim(), doubleValue, words[4].trim());
                    user_temp.setThing(u1);
                    user_temp.setUser_type("CIBBankaccount");
                }
                if (Objects.equals(words[0], "fawryWallet")) {
                    double doubleValue = Double.parseDouble(words[5]);
                    Fawry_wallet u1 = new Fawry_wallet(words[3].trim(), doubleValue, words[4].trim());
                    user_temp.setThing(u1);
                    user_temp.setUser_type("fawryWallet");
                }
                if (Objects.equals(words[0], "vodafoneCashWallet")) {
                    double doubleValue = Double.parseDouble(words[5]);
                    VodafoneCash_wallet u1 = new VodafoneCash_wallet(words[3].trim(), doubleValue, words[4].trim());
                    user_temp.setThing(u1);
                    user_temp.setUser_type("vodafoneCashWallet");
                }
                if (Objects.equals(words[0], "HSBCBankaccount")) {
                    double doubleValue = Double.parseDouble(words[5]);
                    HSBC_account u1 = new HSBC_account(words[3].trim(), doubleValue, words[4].trim());
                    user_temp.setThing(u1);
                    user_temp.setUser_type("HSBCBankaccount");
                }


                user_temp.setUsername(words[1].trim());
                user_temp.setPassword(words[2].trim());
                users.add(user_temp);


            }

        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }


    }

    public boolean login() {
        if (currUser != null) {
            return true;
        }
        Scanner scanner = new Scanner(System.in);
        boolean found = false;

        User tempUser = new User();

        while (!found) {
            System.out.println("Enter your username: ");
            String userN = scanner.next();
            for (User i : users) {
                if (i.getUsername().equals(userN)) {
                    tempUser = i;
                    found = true;
                }
            }
            if (!found) {
                System.out.println("This username is not in the system!");
                return false;
            }

            System.out.println("Enter your password: ");
            String pass = scanner.next();
            if (tempUser.getPassword().equals(pass)) {
                System.out.println("Logging in...");
                currUser = tempUser;
                return true;
//                break;
            } else {
                System.out.println("Password is wrong!");
//                System.out.println("Login again!");
            }
        }
        return false;
    }

    public void UpdateFile(Vector<User> users) {
        String filePath = "Database.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, false))) {
            for (User user1 : users) {
                Writefile(user1);
            }
//

        } catch (IOException e) {
            System.err.println("Error writing to the file: " + e.getMessage());
        }
    }

    public boolean transformation() {
        System.out.println();
        System.out.print("Welcome to main menu, ");
        System.out.println(currUser.getUsername());
        System.out.println("Choose from menu what do you want to do");
        System.out.println("1- Transfer to instapay account");
        System.out.println("2- Transfer to wallet ");
        System.out.println("3- Transfer to bank account ");
        System.out.println("4- Pay bills ");
        System.out.println("5- Inquire about balance");
        System.out.println("6- Logout");
        System.out.println();

        Scanner in = new Scanner(System.in);
        System.out.print("Enter the method number: ");
        int num = in.nextInt();

        if (num == 1) {
            boolean check=false;
            User target=new User();
            transfer = new Tinsta();
            User curr = currUser;

            System.out.println("Enter the username that you want to transfer money to for his/her own account: ");
            String user2 = in.next();
            for (User i : users) {
                if (Objects.equals(i.getUsername(), user2)) {
                    target = i;
                    check=true;
                    break;
                }
            }
            if(check) {
                boolean flag = transfer.process(curr, users, target, transfer);
                if (flag) UpdateFile(users);
            }else {
                System.out.println("username isn't exist,try again.");
                transformation();
            }
            }

        else if (num == 2) {
            boolean check=false;
            transfer = new Twallet();
            User curr = currUser;
            User target=new User();
            in = new Scanner(System.in);
            System.out.println("Enter the phone number that you want to transfer money to for his/her own account: ");
            String user2 = in.next();

            for (User i : users) {
                if (i.getThing() instanceof Wallet && Objects.equals(((Wallet) i.getThing()).getRegistered_mobile_number(), user2)) {
                    target = i;
                    check = true;
                    break;
                }
            }
            if(check){
                boolean flag=transfer.process(curr,users,target,transfer);
                if(flag) UpdateFile(users);
            }else{
                System.out.println("username isn't exist,try again.");
                transformation();
            }


        }
        else if (num == 3) {
            transfer = new Tbank();
            User curr = currUser;
            User target=new User();
            in = new Scanner(System.in);
            String test="Wallet";
            if (curr.getUser_type().contains(test)) {
                System.out.println("Sorry, you can't transfer to bank account");
                transformation();

            }
            System.out.println("Enter the account number that you want to transfer money to for his/her own account: ");
            String user2 = in.next();
            for (User i : users) {
                if (Objects.equals(((Bank_account)i.getThing()).getAccountNumber(), user2)) {
                    target = i;
                    break;
                }
            }
                boolean flag=transfer.process(curr,users,target,transfer);
                if(flag) UpdateFile(users);

        }
        else if (num == 4) {
            System.out.println();
            System.out.println("What is the bill you want to pay?");
            System.out.println("1- Electricity bill");
            System.out.println("2- Water bill");
            System.out.println("3- Gas bill");
            System.out.println("4- Exit");
            System.out.println();

            int bill = in.nextInt();

            if (bill == 1) {
                System.out.println("Enter the number of the bill: ");
                String billNum = in.next();

                // create electricity bill object
                Bill b = new ElectricBill();

                b.processBill(billNum, currUser);

            }
            else if (bill == 2) {
                System.out.println("Enter the number of the bill: ");
                String billNum = in.next();

                // create water bill object
                Bill b = new WaterBill();

                b.processBill(billNum, currUser);

            }
            else if (bill == 3) {
                System.out.println("Enter the number of the bill: ");
                String billNum = in.next();

                // create gas bill object
                Bill b = new GasBill();

                b.processBill(billNum, currUser);

            }
            else if (bill == 4) {
                return true;
            }
            else {
                System.out.println("Invalid input!");

            }
        }
        else if (num == 5) {
            System.out.println("Your balance is : $"+ currUser.getThing().getBalance() +'\n');
        }
        else if (num == 6) {
            currUser = null;
            System.out.println("Logging out...");
            return false;
        }
        else {
            System.out.println("Invalid input!");
        }
        return true;
    }

}
