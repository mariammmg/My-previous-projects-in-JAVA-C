import java.util.HashMap;
import java.util.Map;

public class HSBC_Bank_api implements Bank_api {
    @Override
    public boolean verfication_mobile(String mobileNumber, String accountNumber) {
        Map<String, String> HSBC_accountMobileMap = new HashMap<>();
        HSBC_accountMobileMap.put("123456789", "01045566789");
        HSBC_accountMobileMap.put("127654321", "0104566908");
        return HSBC_accountMobileMap.containsKey(accountNumber) && HSBC_accountMobileMap.get(accountNumber).equals(mobileNumber);
    }
}
