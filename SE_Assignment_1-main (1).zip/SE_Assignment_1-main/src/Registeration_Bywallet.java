import java.util.Objects;
import java.util.Scanner;

public class Registeration_Bywallet implements Registeration_method {
    @Override
    public boolean register(User u1) {
        boolean verify = true;

        if (Objects.equals(u1.getUser_type(), "vodafonecashWallet")) {
            VodafoneCash_wallet acc = (VodafoneCash_wallet) u1.getThing();
            verify = acc.verfiy_wallet(acc.getRegistered_mobile_number());
            if (verify) {
                System.out.println("otp" + 567890 + " is sent to " + acc.getRegistered_mobile_number() + " mobile number");
                Scanner scanner = new Scanner(System.in);
                int num = scanner.nextInt();
                System.out.println("your  wallet is verified");
                return true;
            } else {
                System.out.println("your wallet is not verified");
                return false;
            }
        }
        if (Objects.equals(u1.getUser_type(), "fawryWallet")) {
            Fawry_wallet wallet = (Fawry_wallet) u1.getThing();
            verify = wallet.verfiy_wallet(wallet.getRegistered_mobile_number());
            if (verify) {
                System.out.println("otp" + 567790 + "is sent to " + wallet.getRegistered_mobile_number() + "mobile number");
                Scanner scanner = new Scanner(System.in);
                int num = scanner.nextInt();
                System.out.println("your  wallet is verified");
                return true;
            } else {
                System.out.println("you wallet is not verified");
                return false;
            }
        }


        return true;
    }
}
