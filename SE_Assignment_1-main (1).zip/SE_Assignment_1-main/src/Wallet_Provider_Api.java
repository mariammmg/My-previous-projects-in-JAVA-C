public interface Wallet_Provider_Api {
    boolean verfication(String mobileNumber);
}

