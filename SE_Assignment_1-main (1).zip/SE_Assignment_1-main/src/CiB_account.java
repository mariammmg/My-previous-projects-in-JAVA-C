public class CiB_account extends Bank_account {
    private final String bank_name;
    private final Bank_api api;

    public CiB_account(String num, double balance, String accountnum) {
        super(num, balance, accountnum);
        this.bank_name = "CIB";
        api = new CIB_Bank_api();
    }

    public boolean verfiy_account(String mobile, String accountNumber) {
        return api.verfication_mobile(mobile, accountNumber);
    }
}
