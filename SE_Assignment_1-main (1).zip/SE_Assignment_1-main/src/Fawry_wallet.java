public class Fawry_wallet extends Wallet {
    private final Wallet_Provider_Api api;

    public Fawry_wallet(String num, double balance, String ID) {
        super(num, balance, ID);
        api = new Fawry_Api();
    }

    public boolean verfiy_wallet(String mobile) {
        return api.verfication(mobile);
    }
}
