#ifndef CLION_BANKINGSYSTEM_H
#define CLION_BANKINGSYSTEM_H

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class client;
class BankAccount;

class Client
{
private:
    string name;
    string address;
    string phone;
    BankAccount* account;
public:
    Client(string name, string address, string phone, BankAccount* account);
    string getName();
    string getAddress();
    string getPhone();
    BankAccount* getAccount();
    void setName(string name);
    void setAddress(string address);
    void setPhone(string phone);
    void setAccount(BankAccount* account);
};

class BankAccount
{
private:
    string accountID;
public:
    double balance;
    BankAccount(string accountID, double balance);
    BankAccount();
    string getAccountID();
    double getBalance();
    void setAccountID(string accountID);
    void setBalance(double balance);
    void withdraw(double amount);
    void deposit(double amount);
};

class SavingsBankAccount : public BankAccount
{
private:
    double minimumBalance;
public:
    SavingsBankAccount(string accountID, double balance, double minimumBalance);
    double getMinimumBalance();
    void setMinimumBalance(double minimumBalance);
    void withdraw(double amount);
    void deposit(double amount);
};

class BankingApplication
{
private:
    vector<Client*> clients;
    vector<BankAccount*> accounts;
public:
    BankingApplication();
    void createAccount();
    void listClientsAndAccounts();
    void withdrawMoney();
    void depositMoney();
};

#endif //CLION_BANKINGSYSTEM_H
