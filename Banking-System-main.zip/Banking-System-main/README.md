# Banking-System
we design and develop a banking application. The banking application allows the user, i.e.,  the bank employee to create a bank account for a specific client.  It allows him to list all the available bank accounts.  For each account, it allows him to display the account details, withdraw money and deposit money.
