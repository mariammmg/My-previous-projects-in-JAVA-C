#include "BankingSystem.h"
#include "BankingSystem.cpp"

int main()
{
    BankingApplication* app = new BankingApplication();
    int choice;
    while (true)
    {
        cout << "Welcome to FCAI Banking Application" << endl;
        cout << "1. Create Account" << endl;
        cout << "2. List Clients and Accounts" << endl;
        cout << "3. Withdraw Money" << endl;
        cout << "4. Deposit Money" << endl;
        cout << "5. Exit" << endl;
        cout << "______________" << endl;
        cout << "Please Enter Your Choice =========> ";
        cin >> choice;
        if (choice == 1)
        {
            app->createAccount();
        }
        else if (choice == 2)
        {
            app->listClientsAndAccounts();
        }
        else if (choice == 3)
        {
            app->withdrawMoney();
        }
        else if (choice == 4)
        {
            app->depositMoney();
        }
        else if (choice == 5)
        {
            break;
        }
        else
        {
            cout << "Invalid Choice" << endl;
        }
    }
    return 0;
}
