// FCAI – Object-Oriented Programming 1 – 2022 - Assignment 2
// Program Name: BigReal
// Last Modification Date: 14/11/2022
// Author1 and ID and Group: Nourhan Mahmoud Eldesoky  ID: 20211107
// Author2 and ID and Group: Rawan Hesham Hamdy  ID: 20211040
// Author3 and ID and Group: Mariam Moutaz Mohamed  ID: 20210386
/*
description: In this problem we design and develop a banking application.
The banking application allows the user, i.e.,
 the bank employee to create a bank account for a specific client.
 It allows him to list all the available bank accounts.
 For each account, it allows him to display the account details, withdraw money and deposit money.
 */

#include "BankingSystem.h"

Client::Client(string name, string address, string phone, BankAccount* account)
{
    this->name = name;
    this->address = address;
    this->phone = phone;
    this->account = account;
}

string Client::getName()
{
    return name;
}

string Client::getAddress()
{
    return address;
}

string Client::getPhone()
{
    return phone;
}

BankAccount* Client::getAccount()
{
    return account;
}

void Client::setName(string name)
{
    this->name = name;
}

void Client::setAddress(string address)
{
    this->address = address;
}

void Client::setPhone(string phone)
{
    this->phone = phone;
}

void Client::setAccount(BankAccount* account)
{
    this->account = account;
}

BankAccount::BankAccount(string accountID, double balance)
{
    this->accountID = accountID;
    this->balance = balance;
}

BankAccount::BankAccount()
{
    this->balance = 0;
}

string BankAccount::getAccountID()
{
    return accountID;
}

double BankAccount::getBalance()
{
    return balance;
}

void BankAccount::setAccountID(string accountID)
{
    this->accountID = accountID;
}

void BankAccount::setBalance(double balance)
{
    this->balance = balance;
}

void BankAccount::withdraw(double amount)
{
    if (amount > balance)
    {
        cout << "Sorry. This is more than what you can withdraw." << endl;
    }
    else
    {
        balance -= amount;
        cout << "Thank you. Account ID: " << accountID << " New Balance: " << balance << endl;
    }
}

void BankAccount::deposit(double amount)
{
    if (amount < 100)
    {
        cout << "Sorry. This is less than what you can deposit." << endl;
    }
    else
    {
        balance += amount;
        cout << "Thank you. Account ID: " << accountID << " New Balance: " << balance << endl;
    }
}

SavingsBankAccount::SavingsBankAccount(string accountID, double balance, double minimumBalance) : BankAccount(accountID, balance)
{
    this->minimumBalance = minimumBalance;
}

double SavingsBankAccount::getMinimumBalance()
{
    return minimumBalance;
}

void SavingsBankAccount::setMinimumBalance(double minimumBalance)
{
    this->minimumBalance = minimumBalance;
}

void SavingsBankAccount::withdraw(double amount)
{
    if (amount > balance)
    {
        cout << "Sorry. This is more than what you can withdraw." << endl;
    }
    else if (amount > balance - minimumBalance)
    {
        cout << "Sorry. This is more than what you can withdraw." << endl;
    }
    else
    {
        balance -= amount;
        cout << "Thank you. Account ID: " << getAccountID() << " New Balance: " << balance << endl;
    }
}

void SavingsBankAccount::deposit(double amount)
{
    if (amount < 100)
    {
        cout << "Sorry. This is less than what you can deposit." << endl;
    }
    else
    {
        balance += amount;
        cout << "Thank you. Account ID: " << getAccountID() << " New Balance: " << balance << endl;
    }
}

BankingApplication::BankingApplication()
{
    clients = vector<Client*>();
    accounts = vector<BankAccount*>();
}

void BankingApplication::createAccount()
{
    string name, address, phone, accountID;
    double balance, minimumBalance;
    int accountType;
    cout << "Please Enter The Client Name =========> ";
    cin >> name;
    cout << "Please Enter The Client Address =========> ";
    cin >> address;
    cout << "Please Enter The Client Phone =========> ";
    cin >> phone;
    cout << "Please Enter The Account ID =========> ";
    cin >> accountID;
    cout << "Please Enter The Account Balance =========> ";
    cin >> balance;
    cout << "Please Enter The Account Type (1) Basic (2) Saving =========> ";
    cin >> accountType;
    if (accountType == 1)
    {
        cout << "Please Enter The Minimum Balance =========> ";
        cin >> minimumBalance;
        BankAccount* account = new SavingsBankAccount(accountID, balance, minimumBalance);
        Client* client = new Client(name, address, phone, account);
        clients.push_back(client);
        accounts.push_back(account);
    }
    else if (accountType == 2)
    {
        BankAccount* account = new BankAccount(accountID, balance);
        Client* client = new Client(name, address, phone, account);
        clients.push_back(client);
        accounts.push_back(account);
    }
    else
    {
        cout << "Invalid Account Type" << endl;
    }
    cout << "An account was created with ID "<< accountID << " and Starting Balance " << balance << endl;
}
void BankingApplication::listClientsAndAccounts()
{
    for (int i = 0; i < clients.size(); i++)
    {
        Client* client = clients[i];
        BankAccount* account = client->getAccount();
        cout << "Client Name: " << client->getName() << endl;
        cout << "Client Address: " << client->getAddress() << endl;
        cout << "Client Phone: " << client->getPhone() << endl;
        cout << "Account ID: " << account->getAccountID() << endl;
        cout << "Account Balance: " << account->getBalance() << endl;
        cout << "_______________" << endl;
        cout << endl;
    }
}

void BankingApplication::withdrawMoney()
{
    string accountID;
    double amount;
    cout << "Please Enter The Account ID =========> ";
    cin >> accountID;
    cout << "Please Enter The Amount =========> ";
    cin >> amount;
    for (int i = 0; i < accounts.size(); i++)
    {
        BankAccount* account = accounts[i];
        if (account->getAccountID() == accountID)
        {
            account->withdraw(amount);
            break;
        }
    }
}

void BankingApplication::depositMoney()
{
    string accountID;
    double amount;
    cout << "Please Enter The Account ID =========> ";
    cin >> accountID;
    cout << "Please Enter The Amount =========> ";
    cin >> amount;
    for (int i = 0; i < accounts.size(); i++)
    {
        BankAccount* account = accounts[i];
        if (account->getAccountID() == accountID)
        {
            account->deposit(amount);
            break;
        }
    }
}