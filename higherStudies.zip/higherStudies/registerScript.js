const studentName=localStorage.getItem('name');
const studentId=localStorage.getItem('id');
document.getElementById('student').innerText='student name :  '+studentName;
document.getElementById('Id').innerText='student Id :  '+studentId;



const students = JSON.parse(localStorage.getItem("users")) || [];
function sav()
{
    
    //e.preventDefault(); 
    const ncourse1=document.getElementById('course1field').value;
    const ncourse2=document.getElementById('course2field').value;
const ncourse3=document.getElementById('course3field').value;
    console.log(ncourse2);
    if(students)
{
    console.log('1');
    for(let i = 0; i < students.length; i++)
    {
        console.log('2');
        const student=students[i];
        if(studentId==student.ID)
        {
            //console.log(student);
            students[i].course1= ncourse1;
            students[i].course2=ncourse2;
            students[i].course3=ncourse3;
            console.log(students[i].course2);
            break;
        }


    }
    localStorage.setItem("users", JSON.stringify(students));
}}
/*submitStudentCourse.onclick = function(e) {
    // validate the name input
    e.preventDefault(); 
    sav();
}}*/
