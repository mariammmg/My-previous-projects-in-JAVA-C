const nameInput = document.getElementById('Name');
    const IDInput = document.getElementById('ID');
    const universityInput = document.getElementById('university');
    const DateInput = document.getElementById('Date');
    const nameerror=document.getElementById('NameError');
    const IDerror=document.getElementById('IDError');
    const statusInput=document.getElementsByName('status');
    const genderInputs = document.getElementsByName('gender');
    const submitBtn = document.getElementById('submitBtn');
    const selectElement = document.querySelector("#departments");
    const selectcourse1 = document.querySelector("#course1");
    const selectcourse2 = document.querySelector("#course2");
    const selectcourse3 = document.querySelector("#course3");
    const usersBody=document.querySelector("#studenttable");

// function to validate the name input
function validateName() {
  const name = nameInput.value;
  if (name.trim() === '') {
    nameerror.innerHTML = 'Name is required';
    return false;
  } else if (!/^[a-zA-Z ]+$/.test(name)) {
    nameerror.innerHTML = 'Name must contain only letters and spaces';
    return false;
  } else {
    nameerror.innerHTML = '';
    return true;
  }
}
function validateID() {
    const ID = IDInput.value;
    if (ID.trim() === '') {
      nameerror.innerHTML = 'ID is required';
      return false;
    } else if (!/^[0-9]+$/.test(ID)) {
      IDerror.innerHTML = 'ID must contain only numbers';
      return false;
    } else {
      IDerror.innerHTML = '';
      return true;
    }
  }
  


submitBtn.onclick = function(e) {
  // validate the name input
  e.preventDefault(); 
  if (!validateName()) {
    return;
  };
  if (!validateID()) {
    return;
  };

  // get the values of the input fields
  const name = nameInput.value;
  const ID =IDInput.value;
  const Datein = DateInput.value;
  const university = universityInput.value;
      const dateObject = new Date(Datein);
      const dateString = dateObject.toISOString();
      const selectedDepartment = selectElement.value;
      const course1 = selectcourse1.value;
      const course2 = selectcourse2.value;
      const course3 = selectcourse3.value;
  // get the selected value of the gender radio buttons
  let gender = null;
  for (let i = 0; i < genderInputs.length; i++) {
    if (genderInputs[i].checked) {
      gender = genderInputs[i].value;
      break;
    }
  }
  let radioButtonstatus;
      statusInput.forEach((statusInputs) => {
        if (statusInputs.checked) {
          radioButtonstatus =statusInputs.value;
        }
      });
  
   
  // create a JavaScript object with the input values
  const user = { 
    name: name, 
    radioButtonstatus:radioButtonstatus,
     gender: gender,
     university:university,
     ID:ID,
     Date:dateString,
     Department:selectedDepartment,
     course1:course1,
     course2:course2,
     course3:course3
    };


  let users = JSON.parse(localStorage.getItem('users'));
  
      if (!users) {
        users = [];
      }
      
      users.push(user);
      
      localStorage.setItem('users', JSON.stringify(users));
    }