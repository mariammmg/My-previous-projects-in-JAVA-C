const sname=localStorage.getItem('name');
  const sid=localStorage.getItem('id');
  var statuss =localStorage.getItem('status');
  const Gender=localStorage.getItem('gender');
  var Department=localStorage.getItem('department');
  document.getElementById('Name').value = sname;
  document.getElementById('ID').value = sid;
  const radioButtons = document.querySelectorAll('input[type="radio"]');

// Check the radio button with the matching value
   radioButtons.forEach(button => {
  if (button.value === Gender) {
    button.checked = true;
  }
  });
  radioButtons.forEach(button => {
  if (button.value === statuss) {
    button.checked = true;
  }
  });

  document.getElementById('departments').value = Department;
  const UPDATE = document.getElementById("Update");
        function Update()
        {
          const statusRdioBtns = document.getElementsByName('status');
          var selectedStatus ;
          
          let radioButtonstatus;
          statusRdioBtns.forEach((statusRdioBtn) => 
          {
            if (statusRdioBtn.checked) 
            {
               radioButtonstatus =statusRdioBtn.value;
               selectedStatus=radioButtonstatus;
            }
          });    

            const selectElement = document.querySelector("#departments");
            const selectedDepartment = selectElement.value; 
            const users = JSON.parse(localStorage.getItem('users'));
            if (users) 
            {
              for (let i = 0; i < users.length; i++)
               {
                  const user = users[i];
                  if(user.ID === sid)
                  {
                    user.radioButtonstatus=selectedStatus;
                    user.Department=selectedDepartment;
                    break;
                  }
                }
              localStorage.setItem("users", JSON.stringify(users));
            }
        }
          UPDATE.addEventListener('click',Update);

  var myButton = document.getElementById("DEL");
  myButton.addEventListener("click", function()
  {
    var confirmation = confirm("Are you sure you want to delete this student?");
    if(confirmation == true)
    {
      let users = JSON.parse(localStorage.getItem("users"));
      let indexToRemove = -1;
      for (let i = 0; i < users.length; i++) 
      {
        if (users[i].ID === sid)
        {
          indexToRemove = i;//if exists (used to find the required user to be deleted)
          break;
        }
      }

      // remove the user from the array
      if (indexToRemove !== -1)
       {
          users.splice(indexToRemove, 1);
       }

      // setting the modified array into local storage
      localStorage.setItem("users", JSON.stringify(users));
    }
    else 
    {
      alert("u canceled the deletion");
    }
 });